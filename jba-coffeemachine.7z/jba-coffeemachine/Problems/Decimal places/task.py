value = float(input())
decimals = int(input())
print(f'{value:.{decimals}f}')