class House:
    def __init__(self, floors):
        self.floors = floors
        self.color = None

    def paint(self, color):
        self.color = color
