# the following line reads the input and converts it into a list; do not modify it, please
hidden = list(input())

# your code here
print(len(hidden))