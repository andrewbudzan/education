# put your python code here

value = int(input())

if value > 0:
    print('positive')
elif value < 0:
    print('negative')
else:
    print('zero')
