x1 = int(input())
x2 = int(input())

if x2 > x1:
    print(x2)
    print(x1)
else:
    print(x1)
    print(x2)