def fahrenheit_to_celsius(t_fahr):
    t_cels = (t_fahr - 32) * 5 / 9
    return round(t_cels, 3)

#print(fahrenheit_to_celsius(451))