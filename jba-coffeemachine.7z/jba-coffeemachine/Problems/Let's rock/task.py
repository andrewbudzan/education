# start a RockBand here
class RockBand():
    genre = 'rock'
    n_members = 4
    key_instruments = ['electric guitar', 'drums']


acdc = RockBand()
print(acdc.genre)
print(acdc.n_members)
print(acdc.key_instruments)
