print("'")
print("'\"'")
print("'\"'\"'")
print("'\"'\"'\"'")