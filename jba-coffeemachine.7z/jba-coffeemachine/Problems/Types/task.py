# the variable "args" is already defined
my_list = []  # your code here
for arg in args[1:]:
    my_list.append(int(arg))

print(str(my_list))