# the following line reads the string to work with from the input, do not modify it, please
input_str = input()

# your code here
ls = list(input_str)
print(ls)