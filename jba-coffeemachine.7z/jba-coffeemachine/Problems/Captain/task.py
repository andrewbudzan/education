# declare your function here

def captain_adder(name):
    print(f'captain {name}')