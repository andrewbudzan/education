class Angel:
    color = "white"
    feature = "wings"
    home = "Heaven"


class Demon:
    color = "red"
    feature = "horns"
    home = "Hell"


a = Angel()
print(a.color)
print(a.feature)
print(a.home)
d = Demon()
print(d.color)
print(d.feature)
print(d.home)
