n = int(input())
summ = 0
for i in range(n):
    x = int(input())
    summ += x
mn = summ / n
print(mn)