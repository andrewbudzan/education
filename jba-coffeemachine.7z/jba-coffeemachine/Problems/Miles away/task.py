def mi_to_km(mi):
    return mi * 1.609

# print(mi_to_km(100))