# create a Human here
class Human():
    species = 'Homo Sapiens'
    n_legs = 2
    n_arms = 2