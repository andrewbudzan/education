# JetBrains Academy Learning course
*track*: **Python Developer**

*project*: **Coffee Machine**
